/*******************************************************************************
 * Copyright (c) 2016-2019 Embedded Systems and Applications Group
 * Department of Computer Science, Technische Universitaet Darmstadt,
 * Hochschulstr. 10, 64289 Darmstadt, Germany.
 *
 * All rights reserved.
 *
 * This software is provided free for educational use only.
 * It may not be used for commercial purposes without the
 * prior written permission of the authors.
 ******************************************************************************/
package mavlc.codegen.tam;

import mavlc.errors.InternalCompilerError;
import mavlc.syntax.AstNode;
import mavlc.syntax.AstNodeBaseVisitor;
import mavlc.syntax.expression.*;
import mavlc.syntax.expression.Compare.Comparison;
import mavlc.syntax.function.FormalParameter;
import mavlc.syntax.function.Function;
import mavlc.syntax.module.Module;
import mavlc.syntax.record.RecordElementDeclaration;
import mavlc.syntax.record.RecordTypeDeclaration;
import mavlc.syntax.statement.*;
import mavlc.syntax.type.MatrixTypeSpecifier;
import mavlc.syntax.type.TypeSpecifier;
import mavlc.syntax.type.VectorTypeSpecifier;
import mavlc.type.*;
import mtam.Instruction;
import mtam.Primitive;
import mtam.Register;

import java.util.ArrayList;
import java.util.List;


/*
 * EiCB group number: 35
 * Niels Hartwig Christian Wieser ~ 2336455
 * Hakki Sen ~ 2497575
 * Szilveszter Marcell Pesti ~ 2692429
 */

public class CodeGenerator extends AstNodeBaseVisitor<Instruction, Void> {
	
	protected TamAssembler assembler;
	
	public CodeGenerator(TamAssembler asm) {
		assembler = asm;
	}
	
	@Override
	protected Instruction defaultOperation(AstNode node, Void __) {
		throw new UnsupportedOperationException("Code generation for this element is not implemented!");
	}
	
	/**
	 * A wrapper around the AstNode.accept method which also manages the context stack required for generating certain debug symbols.
	 *
	 * @param node The node to visit (node.accept(this) will be called).
	 * @return The return value of the accept() call.
	 */
	@Override
	public Instruction visit(AstNode node) {
		assembler.pushContext(node);
		Instruction result = node.accept(this);
		assembler.popContext();
		return result;
	}
	
	@Override
	public Instruction visitModule(Module module, Void __) {
		module.functions.forEach(this::visit);
		return null;
	}
	
	@Override
	public Instruction visitFunction(Function functionNode, Void __) {
		assembler.addNewFunction(functionNode);
		
		// set local base offset of all parameters
		int argOffset = 0;
		for(int i = functionNode.parameters.size() - 1; i >= 0; i--) {
			FormalParameter param = functionNode.parameters.get(i);
			argOffset -= param.getType().wordSize;
			param.setLocalBaseOffset(argOffset);
		}
		
		// generate code for statements
		functionNode.body.forEach(this::visit);
		
		// emit return here, since the arg offset is required
		assembler.emitReturn(functionNode.getReturnType().wordSize, -argOffset);
		
		return null;
	}

	@Override
	public Instruction visitValueDefinition(ValueDefinition valueDefinition, Void __) {
		visit(valueDefinition.value);
		assembler.addDeclaredEntity(valueDefinition);
		return null;
	}
	
	@Override
	public Instruction visitVariableDeclaration(VariableDeclaration variableDeclaration, Void __) {
		assembler.emitPush(variableDeclaration.getType().wordSize).addName(variableDeclaration.name);
		assembler.addDeclaredEntity(variableDeclaration);
		return null;
	}
	
	@Override
	public Instruction visitVariableAssignment(VariableAssignment variableAssignment, Void __) {
		visit(variableAssignment.value);
		visit(variableAssignment.identifier);
		assembler.storeToStackAddress(variableAssignment.value.getType().wordSize);
		return null;
	}
	
	@Override
	public Instruction visitLeftHandIdentifier(LeftHandIdentifier leftHandIdentifier, Void __) {
		Declaration decl = leftHandIdentifier.getDeclaration();
		int offset = decl.getLocalBaseOffset();
		assembler.loadAddress(Register.LB, offset);
		return null;
	}
	
	@Override
	public Instruction visitMatrixLhsIdentifier(MatrixLhsIdentifier matrixLhsIdentifier, Void __) {
		Declaration decl = matrixLhsIdentifier.getDeclaration();
		MatrixType matrix = (MatrixType) decl.getType();
		int offset = decl.getLocalBaseOffset();
		assembler.loadAddress(Register.LB, offset);
		visit(matrixLhsIdentifier.colIndexExpression);
		assembler.emitBoundsCheck(0, matrix.cols);
		visit(matrixLhsIdentifier.rowIndexExpression);
		assembler.emitBoundsCheck(0, matrix.rows);
		assembler.loadIntegerValue(matrix.cols);
		assembler.emitIntegerMultiplication();
		assembler.emitIntegerAddition();
		//Multiplications with 1 are unnessessary
		if(matrix.elementType.wordSize != 1) {
			assembler.loadIntegerValue(matrix.elementType.wordSize);
			assembler.emitIntegerMultiplication();
		}
		assembler.emitIntegerAddition();

		return null;
	}
	
	@Override
	public Instruction visitVectorLhsIdentifier(VectorLhsIdentifier vectorLhsIdentifier, Void __) {
		Declaration decl = vectorLhsIdentifier.getDeclaration();
		VectorType vector = (VectorType) decl.getType();
		int offset = decl.getLocalBaseOffset();
		assembler.loadAddress(Register.LB, offset);
		visit(vectorLhsIdentifier.indexExpression);
		assembler.emitBoundsCheck(0, vector.dimension);
		//We can optimize some lines here :D
		if(vector.elementType.wordSize != 1) {
			assembler.loadIntegerValue(vector.elementType.wordSize);
			assembler.emitIntegerMultiplication();
		}
		assembler.emitIntegerAddition();

		return null;
	}
	
	@Override
	public Instruction visitRecordLhsIdentifier(RecordLhsIdentifier recordLhsIdentifier, Void __) {
		Declaration decl = recordLhsIdentifier.getDeclaration();
		RecordType recordType = (RecordType) decl.getType();
		RecordTypeDeclaration recordTypeDeclaration = recordType.typeDeclaration;
		assembler.loadAddress(Register.LB, decl.getLocalBaseOffset());
		int offset = recordTypeDeclaration.getElementOffset(recordLhsIdentifier.elementName);
		if(offset != 0) {
			assembler.loadIntegerValue(offset);
			assembler.emitIntegerAddition();
		}
		return null;
	}
	
	@Override
	public Instruction visitForLoop(ForLoop forLoop, Void __) {
		int initVarOffset = forLoop.getInitVarDeclaration().getLocalBaseOffset();
		int incrVarOffset = forLoop.getIncrVarDeclaration().getLocalBaseOffset();
		
		// evaluate init expression and store to the init variable
		visit(forLoop.initExpression);
		// ..., initValue
		assembler.storeLocalValue(forLoop.initExpression.getType().wordSize, initVarOffset);
		// ...
		
		// jump to the loop condition (this jump needs to backpatched later on)
		Instruction jumpToCondition = assembler.emitJump(-1);
		int loopBodyStart = assembler.getNextInstructionAddress();
		
		// emit loop body
		int nextOffset = assembler.getNextOffset();
		visit(forLoop.body);
		assembler.resetNextOffset(nextOffset);
		
		// evaluate increment expression and store it to the increment variable
		visit(forLoop.incrExpression);
		// ..., incrValue
		assembler.storeLocalValue(forLoop.incrExpression.getType().wordSize, incrVarOffset);
		// ...
		
		// backpatch the jump to the test
		int loopCondition = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpToCondition, loopCondition);
		
		// evaluate the loop condition
		visit(forLoop.loopCondition);
		// ..., bool
		assembler.emitConditionalJump(true, loopBodyStart);
		// ...
		
		return null;
	}
	
	@Override
	public Instruction visitForEachLoop(ForEachLoop forEachLoop, Void __) {
		// save current stack size reserved for locals
		int localSize = assembler.getNextOffset();
		
		Expression struct = forEachLoop.structExpression;
		IteratorDeclaration iterator = forEachLoop.iteratorDeclaration;
		int elementCount = struct.getType().wordSize;
		
		// get base address of the struct and iterator lb offset
		int structBase;
		boolean popStruct = false;
		if(struct instanceof IdentifierReference) {
			// use base address of the identifier
			structBase = ((IdentifierReference) struct).getDeclaration().getLocalBaseOffset();
		} else {
			// evaluate the struct, base address is the current stack top
			popStruct = true;
			structBase = assembler.getNextOffset();
			visit(struct);
			// reserve stack space for struct
			assembler.setNextOffset(assembler.getNextOffset() + elementCount);
		}
		
		
		// load initial value for i
		assembler.loadIntegerValue(0);
		assembler.setNextOffset(assembler.getNextOffset() + 1);
		// reserve space for iterator
		iterator.setLocalBaseOffset(assembler.getNextOffset());
		assembler.setNextOffset(assembler.getNextOffset() + 1);
		
		// loop condition (i < struct.wordSize)
		int loopCondition = assembler.getNextInstructionAddress();
		// ..., i
		assembler.loadValue(Register.ST, 1, -1);
		// ..., i, i
		assembler.loadIntegerValue(elementCount);
		// ..., i, i, count
		assembler.emitIntegerComparison(Comparison.LESS);
		// ..., i, bool
		Instruction jumpToLoopEnd = assembler.emitConditionalJump(false, -1);
		// ..., i
		
		// loop body
		{
			// populate iterator (cur = struct[i])
			// ..., i
			assembler.loadValue(Register.ST, 1, -1);
			// ..., i, i
			assembler.loadAddress(Register.LB, structBase);
			// ..., i, i, &struct
			assembler.emitIntegerAddition();
			// ..., i, &struct[i]
			assembler.loadFromStackAddress(1);
			// ..., i, cur
			
			// execute body
			int nextOffset = assembler.getNextOffset();
			visit(forEachLoop.body);
			assembler.resetNextOffset(nextOffset);
			
			// save value and proceed to next iteration
			if(iterator.isVariable()) {
				// ..., i, cur
				assembler.loadValue(Register.ST, 1, -2);
				// ..., i, cur, i
				assembler.loadAddress(Register.LB, structBase);
				// ..., i, cur, i, &struct
				assembler.emitIntegerAddition();
				// ..., i, cur, &struct[i]
				assembler.storeToStackAddress(1);
				// ..., i
			} else {
				// ..., i, cur
				assembler.emitPop(0, 1);
				// ..., i
			}
			// ..., i
			assembler.emitIncrement();
			// ..., i+1
		}
		assembler.emitJump(loopCondition);
		
		int loopEnd = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpToLoopEnd, loopEnd);
		
		// pop auxiliary values
		if(popStruct)
			assembler.emitPop(0, elementCount + 1);
		else
			assembler.emitPop(0, 1);
		
		// reset local stack size
		assembler.setNextOffset(localSize);
		return null;
	}
	
	@Override
	public Instruction visitIfStatement(IfStatement ifStatement, Void __) {
		visit(ifStatement.condition);
		//assembler.callPrimitive(Primitive.eqI);
		Instruction condI = assembler.emitConditionalJump(0, 0);
		visit(ifStatement.thenStatement);
		Instruction jumpI = assembler.emitJump(0);
		int elseA = assembler.getNextInstructionAddress();
		assembler.backPatchJump(condI, elseA);
		if(ifStatement.hasElseStatement()) 
			visit(ifStatement.elseStatement);
		int endA = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpI, endA);

		return null;
	}
	
	@Override
	public Instruction visitCallStatement(CallStatement callStatement, Void __) {
		visit(callStatement.callExpression);
		
		// discard return value if it exists
		int resultSize = callStatement.callExpression.getCalleeDefinition().getReturnType().wordSize;
		if(resultSize != 0) assembler.emitPop(0, resultSize).addComment("discard return value", false);
		
		return null;
	}
	
	@Override
	public Instruction visitReturnStatement(ReturnStatement returnStatement, Void __) {
		// leave the return value on the stack, the RETURN instruction is emitted in visitFunction
		visit(returnStatement.returnValue);
		return null;
	}
	
	@Override
	public Instruction visitCompoundStatement(CompoundStatement compoundStatement, Void __) {
		compoundStatement.statements.forEach(this::visit);
		return null;
	}
	
	@Override
	public Instruction visitSwitchStatement(SwitchStatement switchCaseStatement, Void __) {
		visit(switchCaseStatement.condition);
		List<Instruction> jumps = new ArrayList<Instruction>();
		//First List all cases, so default will only be called if we didnt match a case
		for (Case c : switchCaseStatement.cases) {
			Instruction jump = visitCase(c, null);
			jumps.add(jump);
		}
		for (Default d : switchCaseStatement.defaults) {
			Instruction jump = visitDefault(d, null);
			jumps.add(jump);
		}
		int end = assembler.getNextInstructionAddress();
		//Backpatch all "break" Statements
		jumps.forEach(jump ->{
			assembler.backPatchJump(jump, end);
		});
		return null;
	}
	
	@Override
	public Instruction visitCase(Case namedCase, Void __) {
		assembler.loadValue(Register.ST, 1, -1);
		visit(namedCase.conditionExpression);
		assembler.callPrimitive(Primitive.eqI);
		Instruction jump = assembler.emitConditionalJump(0, 0);
		visit(namedCase.body);
		Instruction r = assembler.emitJump(0);
		int bodyFin = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jump, bodyFin);
		//Since mavc does include a "break" statement after every case, we need to return our jump at the end, so we can backPatch it, in order to let it point at the end of the switch statement.
		return r;
	}
	
	@Override
	public Instruction visitDefault(Default defaultCase, Void __) {
		visit(defaultCase.body);
		Instruction r = assembler.emitJump(0);
		return r;
	}
	
	@Override
	public Instruction visitMatrixMultiplication(MatrixMultiplication matrixMultiplication, Void __) {
		MatrixType matrixType = (MatrixType) matrixMultiplication.leftOperand.getType();
		
		visit(matrixMultiplication.leftOperand);
		visit(matrixMultiplication.rightOperand);
		
		assembler.loadIntegerValue(matrixType.rows);
		assembler.loadIntegerValue(matrixType.cols);
		assembler.loadIntegerValue(((MatrixType) matrixMultiplication.rightOperand.getType()).cols);
		
		if(matrixType.elementType.equals(IntType.instance))
			assembler.emitIntegerMatrixMultiplication();
		else
			assembler.emitFloatMatrixMultiplication();

		return null;
	}
	
	@Override
	public Instruction visitDotProduct(DotProduct dotProduct, Void __) {
		VectorType vectorType = (VectorType) dotProduct.leftOperand.getType();
		
		visit(dotProduct.leftOperand);
		visit(dotProduct.rightOperand);
		
		assembler.loadIntegerValue(1);
		assembler.loadIntegerValue(vectorType.dimension);
		assembler.loadIntegerValue(1);
		
		// a dot product is basically a matrix multiplication of one vector with the other's transposed form
		if(vectorType.elementType.equals(IntType.instance))
			assembler.emitIntegerMatrixMultiplication();
		else
			assembler.emitFloatMatrixMultiplication();
		
		return null;
	}
	
	private void visitArithmeticOperator(BinaryExpression node, boolean allowLeftStruct, boolean allowRightStruct, boolean allowBothStruct, Primitive intPrimitive, Primitive floatPrimitive) {
		Type resultType = node.getType();
		Type leftType = node.leftOperand.getType();
		Type rightType = node.rightOperand.getType();
		int lSize = leftType.wordSize;
		int rSize = rightType.wordSize;
		
		// evaluate operands
		visit(node.leftOperand);
		visit(node.rightOperand);
		
		if(resultType.equals(IntType.instance)) {
			assembler.callPrimitive(intPrimitive);
			return;
		}
		
		if(resultType.equals(FloatType.instance)) {
			assembler.callPrimitive(floatPrimitive);
			return;
		}
		
		if(leftType instanceof StructType && rightType instanceof StructType) {
			if(!allowBothStruct)
				throw new InternalCompilerError(node.getClass().getSimpleName() + " does not support structures for both operands");
			
			boolean useIntPrimitive = ((StructType) leftType).elementType.equals(IntType.instance);
			
			// ..., left, right
			assembler.loadIntegerValue(0);
			// ..., left, right, i (0)
			int loopBegin = assembler.getNextInstructionAddress();
			
			// load operands
			assembler.loadValue(Register.ST, 1, -1);
			// ..., left, right, i, i
			assembler.loadAddress(Register.ST, -2 - lSize - rSize);
			// ..., left, right, i, i, &left
			assembler.emitIntegerAddition();
			// ..., left, right, i, &left[i]
			assembler.loadFromStackAddress(1);
			// ..., left, right, i, left[i]
			assembler.loadValue(Register.ST, 1, -2);
			// ..., left, right, i, left[i], i
			assembler.loadAddress(Register.ST, -3 - rSize);
			// ..., left, right, i, left[i], i, &right
			assembler.emitIntegerAddition();
			// ..., left, right, i, left[i], &right[i]
			assembler.loadFromStackAddress(1);
			// ..., left, right, i, left[i], right[i]
			
			// combine and store
			assembler.callPrimitive(useIntPrimitive ? intPrimitive : floatPrimitive);
			// ..., left, right, i, elem
			assembler.loadValue(Register.ST, 1, -2);
			// ..., left, right, i, elem, i
			assembler.loadAddress(Register.ST, -3 - lSize - rSize);
			// ..., left, right, i, elem, i, &left
			assembler.emitIntegerAddition();
			// ..., left, right, i, elem, &left[i]
			assembler.storeToStackAddress(1);
			// ..., left, right, i
			
			// increment and check
			assembler.emitIncrement();
			// ..., left, right, i+1
			assembler.loadValue(Register.ST, 1, -1);
			// ..., left, right, i+1, i+1
			assembler.loadIntegerValue(lSize);
			// ..., left, right, i+1, i+1, size
			assembler.emitIntegerComparison(Comparison.LESS);
			// ..., left, right, i+1, bool
			assembler.emitConditionalJump(true, loopBegin);
			// ..., left, right, i+1
			assembler.emitPop(0, 1 + rSize);
			// ..., result
			
			return;
		}
		
		if(leftType instanceof StructType) {
			if(!allowLeftStruct)
				throw new InternalCompilerError(node.getClass().getSimpleName() + " does not support structures for its left operand");
			
			boolean useIntPrimitive = rightType.equals(IntType.instance);
			
			// ..., struct, num
			assembler.loadIntegerValue(0);
			// ..., struct, num, i (0)
			int loopStart = assembler.getNextInstructionAddress();
			
			// load operands
			assembler.loadValue(Register.ST, 1, -1);
			// ..., struct, num, i, i
			assembler.loadAddress(Register.ST, -3 - lSize);
			// ..., struct, num, i, i, &struct
			assembler.emitIntegerAddition();
			// ..., struct, num, i, &struct[i]
			assembler.loadFromStackAddress(1);
			// ..., struct, num, i, struct[i]
			assembler.loadValue(Register.ST, 1, -3);
			// ..., struct, num, i, struct[i], num
			
			// combine and store
			assembler.callPrimitive(useIntPrimitive ? intPrimitive : floatPrimitive);
			// ..., struct, num, i, elem
			assembler.loadValue(Register.ST, 1, -2);
			// ..., struct, num, i, elem, i
			assembler.loadAddress(Register.ST, -4 - lSize);
			// ..., struct, num, i, elem, i, &struct
			assembler.emitIntegerAddition();
			// ..., struct, num, i, elem, &struct[i]
			assembler.storeToStackAddress(1);
			// ..., struct, num, i
			
			// increment and check
			assembler.emitIncrement();
			// ..., struct, num, i+1
			assembler.loadValue(Register.ST, 1, -1);
			// ..., struct, num, i+1, i+1
			assembler.loadIntegerValue(lSize);
			// ..., struct, num, i+1, i+1, size
			assembler.emitIntegerComparison(Comparison.LESS);
			// ..., struct, num, i+1, bool
			assembler.emitConditionalJump(true, loopStart);
			// ..., struct, num, i+1
			assembler.emitPop(0, 2);
			// ..., struct
			
			return;
		}
		
		if(rightType instanceof StructType) {
			if(!allowRightStruct)
				throw new InternalCompilerError(node.getClass().getSimpleName() + " does not support structures for its right operand");
			
			boolean useIntPrimitive = leftType.equals(IntType.instance);
			
			// ..., num, struct
			assembler.loadIntegerValue(0);
			// ..., num, struct, i (0)
			int loopStart = assembler.getNextInstructionAddress();
			
			// load operands
			assembler.loadValue(Register.ST, 1, -1);
			// ..., num, struct, i, i
			assembler.loadAddress(Register.ST, -2 - rSize);
			// ..., num, struct, i, i, &struct
			assembler.emitIntegerAddition();
			// ..., num, struct, i, &struct[i]
			assembler.loadFromStackAddress(1);
			// ..., num, struct, i, struct[i]
			assembler.loadValue(Register.ST, 1, -3 - rSize);
			// ..., num, struct, i, struct[i], num
			
			// combine and store
			assembler.callPrimitive(useIntPrimitive ? intPrimitive : floatPrimitive);
			// ..., num, struct, i, elem
			assembler.loadValue(Register.ST, 1, -2);
			// ..., num, struct, i, elem, i
			assembler.loadAddress(Register.ST, -3 - rSize);
			// ..., num, struct, i, elem, i, &struct
			assembler.emitIntegerAddition();
			// ..., num, struct, i, elem, &struct[i]
			assembler.storeToStackAddress(1);
			// ..., num, struct, i
			
			// increment and check
			assembler.emitIncrement();
			// ..., num, struct, i+1
			assembler.loadValue(Register.ST, 1, -1);
			// ..., num, struct, i+1, i+1
			assembler.loadIntegerValue(rSize);
			// ..., num, struct, i+1, i+1, size
			assembler.emitIntegerComparison(Comparison.LESS);
			// ..., num, struct, i+1, bool
			assembler.emitConditionalJump(true, loopStart);
			// ..., num, struct, i+1
			assembler.emitPop(0, 1);
			// ..., num, struct
			assembler.emitPop(rSize, 1);
			// ..., struct
			
			return;
		}
		
		throw new InternalCompilerError("How did we even get here?");
	}
	
	@Override
	public Instruction visitAddition(Addition addition, Void __) {
		visitArithmeticOperator(addition, false, false, true, Primitive.addI, Primitive.addF);
		return null;
	}
	
	@Override
	public Instruction visitSubtraction(Subtraction subtraction, Void __) {
		visitArithmeticOperator(subtraction, false, false, true, Primitive.subI, Primitive.subF);
		return null;
	}
	
	@Override
	public Instruction visitMultiplication(Multiplication multiplication, Void __) {
		visitArithmeticOperator(multiplication, true, true, true, Primitive.mulI, Primitive.mulF);
		return null;
	}
	
	@Override
	public Instruction visitDivision(Division division, Void __) {
		//DIV by 0 exception is already generated by visitArithmeticOperator
		visitArithmeticOperator(division, false, false, false, Primitive.divI, Primitive.divF);
		return null;
	}
	
	@Override
	public Instruction visitExponentiation(Exponentiation exponentiation, Void __) {
		visitArithmeticOperator(exponentiation, false, false, false, Primitive.powInt, Primitive.powFloat);
		return null;
	}
	
	@Override
	public Instruction visitCompare(Compare compare, Void __) {
		visit(compare.leftOperand);
		visit(compare.rightOperand);
		if(compare.leftOperand.getType().equals(IntType.instance))
			assembler.emitIntegerComparison(compare.comparator);
		else
			assembler.emitFloatComparison(compare.comparator);
		return null;
	}
	
	@Override
	public Instruction visitAnd(And and, Void __) {
		visit(and.leftOperand);
		visit(and.rightOperand);
		assembler.emitLogicalAnd();
		return null;
	}
	
	@Override
	public Instruction visitOr(Or or, Void __) {
		visit(or.leftOperand);
		visit(or.rightOperand);
		assembler.emitLogicalOr();
		return null;
	}
	
	@Override
	public Instruction visitMatrixTranspose(MatrixTranspose matrixTranspose, Void __) {
		MatrixType type = (MatrixType) matrixTranspose.operand.getType();
		visit(matrixTranspose.operand);
		
		// transposition of a single row or column is a no-op
		if(type.cols <= 1 || type.rows <= 1) return null;
		assembler.loadIntegerValue(type.rows);
		assembler.loadIntegerValue(type.cols);
		assembler.emitMatrixTranspose();
		return null;
	}
	
	@Override
	public Instruction visitMatrixRows(MatrixRows rows, Void __) {
		MatrixType type = (MatrixType) rows.operand.getType();
		assembler.loadIntegerValue(type.rows).addComment("matrix rows", false);
		return null;
	}
	
	@Override
	public Instruction visitMatrixCols(MatrixCols cols, Void __) {
		MatrixType type = (MatrixType) cols.operand.getType();
		assembler.loadIntegerValue(type.cols).addComment("matrix cols", false);
		return null;
	}
	
	@Override
	public Instruction visitVectorDimension(VectorDimension vectorDimension, Void __) {
		VectorType type = (VectorType) vectorDimension.operand.getType();
		assembler.loadIntegerValue(type.dimension).addComment("vector dim", false);
		return null;
	}
	
	@Override
	public Instruction visitUnaryMinus(UnaryMinus unaryMinus, Void __) {
		visit(unaryMinus.operand);
		if(unaryMinus.operand.getType().equals(IntType.instance))
			assembler.emitIntegerNegation();
		else
			assembler.emitFloatNegation();
		return null;
		}
	
	@Override
	public Instruction visitNot(Not not, Void __) {
		visit(not.operand);
		assembler.emitLogicalNot();
		return null;
	}
	
	@Override
	public Instruction visitCallExpression(CallExpression callExpression, Void __) {
		// evaluate operands, placing them on the stack in source order
		callExpression.actualParameters.forEach(this::visit);
		assembler.emitFunctionCall(callExpression.getCalleeDefinition());
		return null;
	}
	
	@Override
	public Instruction visitElementSelect(ElementSelect elementSelect, Void __) {
		//Check if Left side is an identifier
		if(elementSelect.structExpression instanceof IdentifierReference){
			IdentifierReference ident = (IdentifierReference) elementSelect.structExpression;
			TypeSpecifier typeSpecifier = ident.getDeclaration().typeSpecifier;

			//Load Base Offset
			assembler.loadAddress(Register.LB, ident.getDeclaration().getLocalBaseOffset());
			int uBound = 0;
			if(elementSelect.structExpression.getType() instanceof VectorType)
				uBound = ((VectorType) elementSelect.structExpression.getType()).dimension;
			if(elementSelect.structExpression.getType() instanceof MatrixType)
				uBound = ((MatrixType) elementSelect.structExpression.getType()).rows;
			visit(elementSelect.indexExpression);
			assembler.emitBoundsCheck(0, uBound);
			if(typeSpecifier instanceof MatrixTypeSpecifier) {
				assembler.loadIntegerValue(((MatrixType) elementSelect.structExpression.getType()).cols);
				assembler.emitIntegerMultiplication(); //rows*rowIndex
				//We called this function recoursivly, so we dont need to put the value on top of the stack.
				return null;
			}
			if(typeSpecifier instanceof VectorTypeSpecifier) {
				VectorTypeSpecifier vTypeSpecifier = (VectorTypeSpecifier) typeSpecifier;
				if(vTypeSpecifier.elementTypeSpecifier.getType().wordSize != 1) {
					assembler.loadIntegerValue(vTypeSpecifier.elementTypeSpecifier.getType().wordSize);
					assembler.emitIntegerMultiplication();
				}
				assembler.emitIntegerAddition();
				assembler.loadFromStackAddress(elementSelect.getType().wordSize);		
				return null;
			}
			throw new UnsupportedOperationException();
		} else if(elementSelect.structExpression instanceof RecordElementSelect) {
			//If stuct is part of record we need to get record intern offsets
			RecordElementSelect recordElementSelect = (RecordElementSelect)elementSelect.structExpression;
			if(recordElementSelect.recordExpression instanceof IdentifierReference)
			{
				IdentifierReference ident = (IdentifierReference) recordElementSelect.recordExpression;
				assembler.loadAddress(Register.LB, ident.getDeclaration().getLocalBaseOffset());
				RecordType recordType = (RecordType) recordElementSelect.recordExpression.getType();
				Type typeSpecifier = recordType.typeDeclaration.getElement(recordElementSelect.elementName).getType();
				int offset = recordType.typeDeclaration.getElementOffset(recordElementSelect.elementName);
				if(offset != 0) {
					assembler.loadIntegerValue(offset);
					assembler.emitIntegerAddition();
				}

				//Loaded baseaddress of elemet now

				int uBound = 0;
				if(typeSpecifier instanceof VectorType)
					uBound = ((VectorType) typeSpecifier).dimension;
				if(typeSpecifier instanceof MatrixType)
					uBound = ((MatrixType) typeSpecifier).rows;
				visit(elementSelect.indexExpression);
				assembler.emitBoundsCheck(0, uBound);
				if(typeSpecifier instanceof MatrixType) {
					if(((MatrixType) typeSpecifier).cols != 1) {
						assembler.loadIntegerValue(((MatrixType) typeSpecifier).cols);
						assembler.emitIntegerMultiplication(); //rows*rowIndex
					}
					//If we are in a matrix we called this function recoursivly, so we only need to load the row index.
					return null;
				}
				if(typeSpecifier instanceof VectorType) {
					//Vectors dont get called recoursivly, so we need to load the actual value
					assembler.emitIntegerAddition();
					assembler.loadFromStackAddress(elementSelect.getType().wordSize);		
					return null;
				}
				return null;
			}
		} else {
			//We are in a matrix and calling the function semi recoursivly
			visit(elementSelect.structExpression);			
			int dimension = 1;
			int wordSize = ((StructType)elementSelect.structExpression.getType()).elementType.wordSize;
			if(elementSelect.structExpression.getType() instanceof VectorType)
				dimension = ((VectorType) elementSelect.structExpression.getType()).dimension;
			if(elementSelect.structExpression.getType() instanceof MatrixType)
				dimension = ((MatrixType) elementSelect.structExpression.getType()).cols;
			visit(elementSelect.indexExpression);
			assembler.emitBoundsCheck(0, dimension);
			assembler.emitIntegerAddition();
			//Multiplication with wordsize is only nessessary if wordsize is != 1
			if(wordSize != 1) {
				assembler.loadIntegerValue(wordSize);
				assembler.emitIntegerMultiplication();
			}
			assembler.emitIntegerAddition();
			assembler.loadFromStackAddress(wordSize);
			
			return null;
		}
		return null;
	}
	
	@Override
	public Instruction visitRecordElementSelect(RecordElementSelect recordElementSelect, Void __) {
		Type elementType = recordElementSelect.getType();
		RecordType recordType = (RecordType) recordElementSelect.recordExpression.getType();
		int offset = recordType.typeDeclaration.getElementOffset(recordElementSelect.elementName);
		
		// ...
		visit(recordElementSelect.recordExpression);
		// ..., record
		assembler.loadAddress(Register.ST, -recordType.wordSize + offset);
		// ..., record, &record[offset]
		assembler.loadFromStackAddress(elementType.wordSize);
		// ..., record, result
		assembler.emitPop(elementType.wordSize, recordType.wordSize);
		// ..., result
		return null;
	}
	
	@Override
	public Instruction visitSubMatrix(SubMatrix subMatrix, Void __) {
		MatrixType matrix = (MatrixType) subMatrix.structExpression.getType();
		MatrixType result = (MatrixType) subMatrix.getType();
		int matSize = matrix.wordSize;
		int resSize = result.wordSize;
		
		int rowStartOffset = subMatrix.getRowStartOffset();
		int colStartOffset = subMatrix.getColStartOffset();
		
		// ...
		visit(subMatrix.structExpression);
		// ..., mat
		assembler.emitPush(resSize);
		// ..., mat, res
		assembler.loadAddress(Register.ST, -matSize - resSize);
		// ..., mat, res, &mat
		visit(subMatrix.rowBaseIndexExpression);
		if(rowStartOffset != 0) {
			assembler.loadIntegerValue(rowStartOffset);
			assembler.emitIntegerAddition();
		}
		assembler.emitBoundsCheck(0, matrix.rows - result.rows + 1);
		// ..., mat, res, &mat, minRow
		assembler.loadIntegerValue(matrix.cols);
		assembler.emitIntegerMultiplication();
		assembler.emitIntegerAddition();
		// ..., mat, res, &mat[minRow][0]
		visit(subMatrix.colBaseIndexExpression);
		if(colStartOffset != 0) {
			assembler.loadIntegerValue(colStartOffset);
			assembler.emitIntegerAddition();
		}
		assembler.emitBoundsCheck(0, matrix.cols - result.cols + 1);
		// ..., mat, res, &mat[minRow][0], minCol
		assembler.emitIntegerAddition();
		// ..., mat, res, &mat[minRow][minCol]
		assembler.loadAddress(Register.ST, -resSize - 1);
		// ..., mat, res, &mat[minRow][minCol], &res
		assembler.loadIntegerValue(0);
		// ..., mat, res, &mat[minRow][minCol], &res, i (0)
		
		// loop header
		int loopStart = assembler.getNextInstructionAddress();
		// ..., mat, res, srcPtr, dstPtr, i
		assembler.loadValue(Register.ST, 1, -1);
		// ..., mat, res, srcPtr, dstPtr, i, i
		Instruction jumpEnd = assembler.emitConditionalJump(result.rows, -1); // break if i == result.rows
		// ..., mat, res, srcPtr, dstPtr, i
		
		// copy row
		assembler.loadValue(Register.ST, 1, -3);
		// ..., mat, res, srcPtr, dstPtr, i, srcPtr
		assembler.loadFromStackAddress(result.cols);
		// ..., mat, res, srcPtr, dstPtr, i, row
		assembler.loadValue(Register.ST, 1, -2 - result.cols);
		// ..., mat, res, srcPtr, dstPtr, i, row, dstPtr
		assembler.storeToStackAddress(result.cols);
		// ..., mat, res, srcPtr, dstPtr, i
		
		// increment
		assembler.loadValue(Register.ST, 1, -3);
		// ..., mat, res, srcPtr, dstPtr, i, srcPtr
		assembler.loadIntegerValue(matrix.cols);
		// ..., mat, res, srcPtr, dstPtr, i, srcPtr, matCols
		assembler.emitIntegerAddition();
		// ..., mat, res, srcPtr, dstPtr, i, srcPtr'
		assembler.storeValue(Register.ST, 1, -4);
		// ..., mat, res, srcPtr', dstPtr, i
		assembler.loadValue(Register.ST, 1, -2);
		// ..., mat, res, srcPtr', dstPtr, i, dstPtr
		assembler.loadIntegerValue(result.cols);
		// ..., mat, res, srcPtr', dstPtr, i, dstPtr, resCols
		assembler.emitIntegerAddition();
		// ..., mat, res, srcPtr', dstPtr, i, dstPtr'
		assembler.storeValue(Register.ST, 1, -3);
		// ..., mat, res, srcPtr', dstPtr', i
		assembler.emitIncrement();
		// ..., mat, res, srcPtr', dstPtr', i'
		
		assembler.emitJump(loopStart);
		int loopEnd = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpEnd, loopEnd);
		
		// ..., mat, res, srcPtr, dstPtr, i
		assembler.emitPop(0, 3);
		// ..., mat, res
		assembler.emitPop(resSize, matSize);
		// ..., res
		
		return null;
	}
	
	@Override
	public Instruction visitSubVector(SubVector subVector, Void __) {
		int startOffset = subVector.getStartOffset();
		
		int resSize = subVector.getType().wordSize;
		int vecSize = subVector.structExpression.getType().wordSize;
		
		// ...
		visit(subVector.structExpression);
		// ..., vec
		assembler.loadAddress(Register.ST, -vecSize);
		// ..., vec, &vec
		visit(subVector.baseIndexExpression);
		// ..., vec, &vec, base
		assembler.loadIntegerValue(startOffset);
		// ..., vec, &vec, base, start
		assembler.emitIntegerAddition();
		// ..., vec, &vec, base+start
		assembler.emitBoundsCheck(0, vecSize - resSize + 1);
		// ..., vec, &vec, base+start
		assembler.emitIntegerAddition();
		// ..., vec, &vec[base+start]
		assembler.loadFromStackAddress(resSize);
		// ..., vec, result
		assembler.emitPop(resSize, vecSize);
		// ..., result
		
		return null;
	}
	
	@Override
	public Instruction visitStructureInit(StructureInit structureInit, Void __) {
		structureInit.elements.forEach(this::visit);
		return null;
	}
	
	@Override
	public Instruction visitStringValue(StringValue stringValue, Void __) {
		assembler.loadStringValue(stringValue.value);
		return null;
	}
	
	@Override
	public Instruction visitBoolValue(BoolValue boolValue, Void __) {
		assembler.loadBooleanValue(boolValue.value);
		return null;
	}
	
	@Override
	public Instruction visitIntValue(IntValue intValue, Void __) {
		assembler.loadIntegerValue(intValue.value);
		return null;
	}
	
	@Override
	public Instruction visitFloatValue(FloatValue floatValue, Void __) {
		assembler.loadFloatValue(floatValue.value);
		return null;
	}
	
	@Override
	public Instruction visitIdentifierReference(IdentifierReference identifierReference, Void __) {
		Declaration decl = identifierReference.getDeclaration();
		int wordSize = decl.getType().wordSize;
		int offset = decl.getLocalBaseOffset();
		assembler.loadLocalValue(wordSize, offset).addName(identifierReference.name)
		/*/.addComment("load identifier '" + identifierReference.name + "'")/**/;
		return null;
	}
	
	@Override
	public Instruction visitSelectExpression(SelectExpression exp, Void __) {
		// evaluate condition
		visit(exp.condition);
		// jump over 'then' branch
		Instruction jumpOverThen = assembler.emitConditionalJump(false, -1);
		visit(exp.trueCase);
		Instruction jumpOverElse = assembler.emitJump(-1);
		
		// backpatch jump to 'else' branch
		int afterThen = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpOverThen, afterThen);
		visit(exp.falseCase);
		
		// backpatch jump over 'else' branch
		int afterElse = assembler.getNextInstructionAddress();
		assembler.backPatchJump(jumpOverElse, afterElse);
		
		return null;
	}
}
