#ifndef SORTED_LIST_H
#define SORTED_LIST_H

typedef struct SortedLinkedListNode SortedLinkedListNode;

struct SortedLinkedListNode {
    SortedLinkedListNode* next;
    int value;
};

typedef struct {
    SortedLinkedListNode* first;
}SortedLinkedList;


SortedLinkedList* SortedLinkedList_create();

void SortedLinkedList_addToList(SortedLinkedList* list, int data);

void SortedLinkedList_delete(SortedLinkedList* list);

SortedLinkedListNode* SortedLinkedList_getSmallest(SortedLinkedList* list);

#endif