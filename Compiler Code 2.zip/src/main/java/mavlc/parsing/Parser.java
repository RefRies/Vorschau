/*******************************************************************************
 * Copyright (c) 2016-2019 Embedded Systems and Applications Group
 * Department of Computer Science, Technische Universitaet Darmstadt,
 * Hochschulstr. 10, 64289 Darmstadt, Germany.
 *
 * All rights reserved.
 *
 * This software is provided free for educational use only.
 * It may not be used for commercial purposes without the
 * prior written permission of the authors.
 ******************************************************************************/
package mavlc.parsing;

import mavlc.errors.SyntaxError;
import mavlc.syntax.SourceLocation;
import mavlc.syntax.expression.*;
import mavlc.syntax.function.FormalParameter;
import mavlc.syntax.function.Function;
import mavlc.syntax.module.Module;
import mavlc.syntax.record.RecordElementDeclaration;
import mavlc.syntax.record.RecordTypeDeclaration;
import mavlc.syntax.statement.*;
import mavlc.syntax.type.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;

import static mavlc.parsing.Token.TokenType.*;
import static mavlc.syntax.expression.Compare.Comparison.*;

/* group information:
 *
 * Group number: 35
 * Niels Hartwig Christian Wieser ~ 2336455
 * Hakki Sen ~ 2497575
 * Szilveszter Marcell Pesti ~ 2692429
 */

/**
 * A recursive-descent parser for MAVL.
 */
public final class Parser {
	
	private final Deque<Token> tokens;
	private Token currentToken;
	
	/**
	 * @param tokens A token stream that was produced by the {@link Scanner}.
	 */
	public Parser(Deque<Token> tokens) {
		this.tokens = tokens;
		currentToken = tokens.poll();
	}
	
	/**
	 * Parses the MAVL grammar's start symbol, Module.
	 *
	 * @return A {@link Module} node that is the root of the AST representing the tokenized input program.
	 * @throws SyntaxError to indicate that an unexpected token was encountered.
	 */
	public Module parse() {
		SourceLocation location = currentToken.sourceLocation;
		
		List<Function> functions = new ArrayList<>();
		List<RecordTypeDeclaration> records = new ArrayList<>();
		while(currentToken.type != EOF) {
			switch(currentToken.type) {
				case FUNCTION:
					functions.add(parseFunction());
					break;
				case RECORD:
					records.add(parseRecordTypeDeclaration());
					break;
				default:
					throw new SyntaxError(currentToken, FUNCTION, RECORD);
			}
		}
		return new Module(location, functions, records);
	}
	
	private String accept(Token.TokenType type) {
		Token t = currentToken;
		if(t.type != type)
			throw new SyntaxError(t, type);
		acceptIt();
		return t.spelling;
	}
	
	private void acceptIt() {
		currentToken = tokens.poll();
		if(currentToken == null || currentToken.type == ERROR)
			throw new SyntaxError(currentToken != null ? currentToken : new Token(EOF, null, -1, -1));
	}
	
	private Function parseFunction() {
		SourceLocation location = currentToken.sourceLocation;

		accept(FUNCTION);
		TypeSpecifier typeSpecifier = parseTypeSpecifier();
		String name = accept(ID);
		
		List<FormalParameter> parameters = new ArrayList<>();
		List<Statement> body = new ArrayList<>();
		
		accept(LPAREN);
		if(currentToken.type != RPAREN) {
			parameters.add(parseFormalParameter());
			while(currentToken.type != RPAREN) {
				accept(COMMA);
				parameters.add(parseFormalParameter());
			}
		}
		accept(RPAREN);
		
		accept(LBRACE);
		while(currentToken.type != RBRACE)
			body.add(parseStatement());
		accept(RBRACE);
		
		return new Function(location, name, typeSpecifier, parameters, body);
	}
	
	private FormalParameter parseFormalParameter() {
		SourceLocation location = currentToken.sourceLocation;
		
		TypeSpecifier typeSpecifier = parseTypeSpecifier();
		String name = accept(ID);
		
		return new FormalParameter(location, name, typeSpecifier);
	}
	
	private RecordTypeDeclaration parseRecordTypeDeclaration() {
		SourceLocation location = currentToken.sourceLocation;
		
		accept(RECORD);
		String name = accept(ID);
		accept(LBRACE);
		List<RecordElementDeclaration> elements = new ArrayList<>();
		// no empty records allowed
		elements.add(parseRecordElementDeclaration());
		while(currentToken.type != RBRACE) {
			elements.add(parseRecordElementDeclaration());
		}
		accept(RBRACE);
		
		return new RecordTypeDeclaration(location, name, elements);
	}
	
	private RecordElementDeclaration parseRecordElementDeclaration() {
		SourceLocation location = currentToken.sourceLocation;
		
		boolean isVariable;
		switch(currentToken.type) {
			case VAL:
				acceptIt();
				isVariable = false;
				break;
			case VAR:
				acceptIt();
				isVariable = true;
				break;
			default:
				throw new SyntaxError(currentToken, VAL, VAR);
		}
		
		TypeSpecifier typeSpecifier = parseTypeSpecifier();
		String name = accept(ID);
		accept(SEMICOLON);
		
		return new RecordElementDeclaration(location, isVariable, typeSpecifier, name);
	}
	
	private IteratorDeclaration parseIteratorDeclaration() {
		SourceLocation location = currentToken.sourceLocation;
		boolean isVariable;
		switch (currentToken.type) {
			case VAR:
				acceptIt();
				isVariable = true;
				break;
			case VAL:
				acceptIt();
				isVariable = false;
				break;
			default:
				throw new SyntaxError(currentToken, VAR, VAL);
		}
		TypeSpecifier type = parseTypeSpecifier();
		String name = accept(ID);
		return new IteratorDeclaration(location, name, type, isVariable);
	}
	
	private TypeSpecifier parseTypeSpecifier() {
		SourceLocation location = currentToken.sourceLocation;
		
		boolean vector = false;
		switch(currentToken.type) {
			case INT:
				acceptIt();
				return new IntTypeSpecifier(location);
			case FLOAT:
				acceptIt();
				return new FloatTypeSpecifier(location);
			case BOOL:
				acceptIt();
				return new BoolTypeSpecifier(location);
			case VOID:
				acceptIt();
				return new VoidTypeSpecifier(location);
			case STRING:
				acceptIt();
				return new StringTypeSpecifier(location);
			case VECTOR:
				accept(VECTOR);
				vector = true;
				break;
			case MATRIX:
				accept(MATRIX);
				break;
			case ID:
				String name = accept(ID);
				return new RecordTypeSpecifier(location, name);
			default:
				throw new SyntaxError(currentToken, INT, FLOAT, BOOL, VOID, STRING, VECTOR, MATRIX, ID);
		}
		
		accept(LANGLE);
		TypeSpecifier subtype;
		switch(currentToken.type) {
			case INT:
				subtype = new IntTypeSpecifier(currentToken.sourceLocation);
				break;
			case FLOAT:
				subtype = new FloatTypeSpecifier(currentToken.sourceLocation);
				break;
			default:
				throw new SyntaxError(currentToken, INT, FLOAT);
		}
		acceptIt();
		accept(RANGLE);
		accept(LBRACKET);
		Expression x = parseExpr();
		accept(RBRACKET);
		
		if(vector)
			return new VectorTypeSpecifier(location, subtype, x);
		
		accept(LBRACKET);
		Expression y = parseExpr();
		accept(RBRACKET);
		
		return new MatrixTypeSpecifier(location, subtype, x, y);
	}
	
	private Statement parseStatement() {
		switch(currentToken.type) {
			case VAL:
				return parseValueDef();
			case VAR:
				return parseVarDecl();
			case RETURN:
				return parseReturn();
			case ID:
				return parseAssignOrCall();
			case FOR:
				return parseFor();
			case FOREACH:
				return parseForEach();
			case IF:
				return parseIf();
			case SWITCH:
				return parseSwitch();
			case LBRACE:
				return parseCompound();
			default:
				throw new SyntaxError(currentToken, VAL, VAR, RETURN, ID, FOR, FOREACH, IF, SWITCH, LBRACE);
		}
	}
	
	/**
     * Parses a value definition.
     *
     * <p>A value definition has the form:
     *
     * 'val' type ID '=' expr ';'
     *
     * An example for such a definition would be:
     *
     * val int x = 5;
     *
     * @return ValueDefinition
     */
	private ValueDefinition parseValueDef() {
		SourceLocation location = currentToken.sourceLocation;
		accept(VAL);
		TypeSpecifier type = parseTypeSpecifier();
		String name = accept(ID);
		accept(ASSIGN);
		Expression expr = parseExpr();
		accept(SEMICOLON);

		return new ValueDefinition(location, type, name, expr);
	}
	
	/**
     * Parses a variable declaration.
     *
     * <p>A variable declaration has the form
     *
     * 'var' type ID ';'
     *
     * An example for such a declaration would be:
     *
     * var int x;
     *
     * @return VariableDeclaration
     */
	private VariableDeclaration parseVarDecl() {
		SourceLocation location = currentToken.sourceLocation;
		accept(VAR);
		TypeSpecifier type = parseTypeSpecifier();
		String name = accept(ID);
		accept(SEMICOLON);

		return new VariableDeclaration(location, type, name);
	}
	
	 /**
     * Parses a return declaration.
     *
     * <p>A return declaration has the form
     *
     * 'return' expr ';'
     *
     * An example for such a declaration would be:
     *
     * return x;
     *
     * @return ReturnStatement
     */
	private ReturnStatement parseReturn() {
		SourceLocation location = currentToken.sourceLocation;
		accept(RETURN);
		Expression expr = parseExpr();
		accept(SEMICOLON);
		return new ReturnStatement(location, expr);
	}
	
	private Statement parseAssignOrCall() {
		SourceLocation location = currentToken.sourceLocation;
		
		String name = accept(ID);
		
		Statement s;
		if(currentToken.type != LPAREN)
			s = parseAssign(name, location);
		else
			s = new CallStatement(location, parseCall(name, location));
		accept(SEMICOLON);
		
		return s;
	}
	

    /**
     * Parses the right side (after the identifier) of a variable assignment.
     *
     * <p>Variable Assignment has the form:
     *
     * ID (('[' expr ']' ('[' expr ']')? | '@' ID)? '=' expr ';'
     *
     * An example statement would be:
     *
     * my_vector[5] = 9;
     *
     * This pases the right part of this, everything after the `ID` except the semicolon.
     *
     * @see parseAssignOrCall()
     * @param name: Name of the variable that is assigned.
     * @param location: Line/Column on/in which the variable is specified
     * @return VariableAssignment
     */
	private VariableAssignment parseAssign(String name, SourceLocation location) {
		LeftHandIdentifier lhi;

		switch(currentToken.type) {
			//Matrix or Vector
			case LBRACKET:
				Expression a;
				acceptIt();
				a = parseExpr();
				accept(RBRACKET);
				lhi = new VectorLhsIdentifier(location, name, a); 
				if(currentToken.type == LBRACKET) {
					Expression b;
					acceptIt();
					b = parseExpr();
					accept(RBRACKET);
					lhi = new MatrixLhsIdentifier(location, name, a, b);
				}
				break;
			case AT:
				acceptIt();
				lhi = new RecordLhsIdentifier(location, name, accept(ID));
				break;
			default:
				//Neither @ nor matrix/vector
				lhi = new LeftHandIdentifier(location, name);
				break;
		}
		accept(ASSIGN);
		return new VariableAssignment(location, lhi, parseExpr());
	}
	
	    /**
     * Parses a call declaration.
     *
     * <p>A call declaration has the form
     *
     * method'('parameters')' ';'
     *
     * @param location: Line/Column on/in which the variable is specified
     * @param name: Name of a variable
     * @param parameters -> Arraylist for expressions?
     * @return CallExpression
     */
	private CallExpression parseCall(String name, SourceLocation location) {
		accept(LPAREN);
		List<Expression> parameters = new ArrayList<Expression>();
		if (currentToken.type != RPAREN)
			parameters.add(parseExpr());

		while (currentToken.type == COMMA) {
			acceptIt();
			parameters.add(parseExpr());
		}
		accept(RPAREN);
		return new CallExpression(location, name, parameters);
	}
	
	private ForLoop parseFor() {
		SourceLocation location = currentToken.sourceLocation;
		
		accept(FOR);
		accept(LPAREN);
		String name = accept(ID);
		accept(ASSIGN);
		Expression a = parseExpr();
		accept(SEMICOLON);
		Expression b = parseExpr();
		accept(SEMICOLON);
		String inc = accept(ID);
		accept(ASSIGN);
		Expression c = parseExpr();
		accept(RPAREN);
		return new ForLoop(location, name, a, b, inc, c, parseStatement());
	}
	
	
	/**
     * Parses a ForEach declaration.
     *
     * <p>A ForEach declaration has the form
     *
     * foreach'(' iteration ':' expr')' '{}'
     *
     * @return ForEachLoop
     */
	private ForEachLoop parseForEach() {
		SourceLocation location = currentToken.sourceLocation;

		accept(FOREACH);
		accept(LPAREN);
		IteratorDeclaration iterator = parseIteratorDeclaration();
		accept(COLON);
		Expression expr = parseExpr();
		accept(RPAREN);
		Statement stmt = parseStatement();
		return new ForEachLoop(location, iterator, expr, stmt);
	}
	

	/**
	 * Parses a if-(else)-Statement as defined by:
	 * <p>if ::= ’if’ ’(’ expr ’)’ statement ( ’else’ statement )?
	 * <p>The else statement is optional.
	 *
	 * 
	 * @return {@link IfStatement}
	 */
	private IfStatement parseIf() {
		SourceLocation location = currentToken.sourceLocation;

		accept(IF);
		accept(LPAREN);
		Expression expression = parseExpr();
		accept(RPAREN);
		Statement ifStmt = parseStatement();
		if(currentToken.type == ELSE){
			acceptIt();
			return new IfStatement(location, expression, ifStmt, parseStatement());
		}
		return new IfStatement(location, expression, ifStmt);
	}
	

	/**
	 * Parses a switch-Statement as defined by:
	 * <p>switch ::= ’switch’ ’(’expr’)’ ’{’ switchSection* ’}’
	 *
	 * 
	 * @return {@link IfStatement}
	 * @throws SyntaxError to indicate that a wrong token was used.
	 */
	private SwitchStatement parseSwitch() {
		SourceLocation location = currentToken.sourceLocation;

		accept(SWITCH);
		accept(LPAREN);
		Expression switchExpr = parseExpr();
		accept(RPAREN);
		accept(LBRACE);
		List<Case> cases 		= new ArrayList<>();
		List<Default> defaults 	= new ArrayList<>();

		while (currentToken.type != RBRACE) {
			switch(currentToken.type) {
				case CASE:
					cases.add(parseCase());
					break;
				case DEFAULT:
					defaults.add(parseDefault());
					break;
				default:
					throw new SyntaxError(currentToken, CASE, DEFAULT);
			}
		}
		acceptIt();
		return new SwitchStatement(location, switchExpr, cases, defaults);
	}


	/**
	 * Parses a case-block contained by a switch-Statement as defined by:
	 * <p>case ::= ’case’ expr ’:’ statement
	 *
	 * 
	 * @return {@link Case}
	 */
	private Case parseCase() {
		SourceLocation location = currentToken.sourceLocation;

		accept(CASE);
		Expression condition = parseExpr();
		accept(COLON);
		return new Case(location, condition, parseStatement());
	}

	/**
	 * Parses a default-block contained by a switch-Statement as defined by:
	 * <p>default ::= ’default’ ’:’ statement
	 *
	 * 
	 * @return {@link Default}
	 */
	private Default parseDefault() {
		SourceLocation location = currentToken.sourceLocation;

		accept(DEFAULT);
		accept(COLON);
		return new Default(location, parseStatement());
	}
	
		/**
	 * Parses a Compound as Defined by:
	 * <p>compound ::= ’{’ statement* ’}’
	 *
	 * 
	 * @return {@link CompoundStatement}
	 */
	private CompoundStatement parseCompound() {
		SourceLocation location = currentToken.sourceLocation;
		List<Statement> statements = new ArrayList<>();


		accept(LBRACE);
		while(currentToken.type != RBRACE) {
			statements.add(parseStatement());
		}
		acceptIt();
		return new CompoundStatement(location, statements);
	}
	
	private Expression parseExpr() {
		return parseSelect();
	}
	
	private Expression parseSelect() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression cond = parseOr();
		if(currentToken.type == QMARK) {
			acceptIt();
			Expression trueCase = parseOr();
			accept(COLON);
			Expression falseCase = parseOr();
			return new SelectExpression(location, cond, trueCase, falseCase);
		}
		return cond;
	}
	
	private Expression parseOr() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseAnd();
		while(currentToken.type == OR) {
			acceptIt();
			x = new Or(location, x, parseAnd());
		}
		return x;
	}
	
	private Expression parseAnd() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseNot();
		while(currentToken.type == AND) {
			acceptIt();
			x = new And(location, x, parseNot());
		}
		return x;
	}
	

	/**
	 * Parses a negation as Defined by:
	 * <p>not ::= ’!’ ? compare
	 * <p>If no negation occures, the result of {@link parseCompare} will be returned.
	 *
	 * 
	 * @return {@link Not} or the result of {@link parseCompare()}
	 */
	private Expression parseNot() {
		SourceLocation location = currentToken.sourceLocation;
		
		if(currentToken.type == NOT) {
			acceptIt();
			return new Not(location, parseCompare());
		}
		return parseCompare();
	}
	

	/**
	 * Parses a comparision as defined by:
	 * <p> compare ::= addSub ( ( ’>’ | ’<’ | ’<=’ | ’>=’ | ’==’ | ’!=’ ) addSub )*
	 * <p>If no comparision occures, the result of {@link parseAddSub} will be returned.
	 *
	 * 
	 * @return {@link Compare} or the result of {@link parseAddSub()}
	 */
	private Expression parseCompare() {
		SourceLocation location = currentToken.sourceLocation;
		Expression left = parseAddSub();

		while (true) {
			switch (currentToken.type) {
				case LANGLE:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.LESS);
					break;
				case RANGLE:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.GREATER);
					break;
				case CMPLE:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.LESS_EQUAL);
					break;
				case CMPGE:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.GREATER_EQUAL);
					break;
				case CMPEQ:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.EQUAL);
					break;
				case CMPNE:
					acceptIt();
					left = new Compare(location, left, parseAddSub(), Compare.Comparison.NOT_EQUAL);
					break;
				default:
					return left;
			}
		}
	}
	

	/**
	 * Parses a Addition or Subtraction as defined by:
	 * <p>addSub ::= mulDiv ( ( ’+’ | ’-’ ) mulDiv )*
	 * <p>If no Addition or subtraction occures, the result of {@link parseMulDiv} will be returned.
	 *
	 * 
	 * @return {@link Addition} / {@link Subtraction} or the result of {@link parseMulDiv()} 
	 */
	private Expression parseAddSub() {
		SourceLocation location = currentToken.sourceLocation;
		Expression left = parseMulDiv();

		while (true) {
			switch (currentToken.type) {
				case ADD:
					acceptIt();
					left = new Addition(location, left, parseMulDiv());
					break;
				case SUB:
					acceptIt();
					left = new Subtraction(location, left, parseMulDiv());
					break;
				default:
					return left;
			}
		}
	}
	

	/**
	 * Parses a Multiplication or Division as defined by:
	 * <p>mulDiv ::= unaryMinus ( ( ’*’ | ’/’ ) unaryMinus )*
	 * <p>If no Multiplikation or Division occures, the result of {@link parseUnaryMinus} will be returned.
	 * 
	 * 
	 * @return {@link Multiplication} / {@link Division} or the result of {@link parseUnaryMinus()}
	 */
	private Expression parseMulDiv() {
		SourceLocation location = currentToken.sourceLocation;
		Expression left = parseUnaryMinus();
		Expression right;

		while (true) {
			switch (currentToken.type) {
				case MULT:
					acceptIt();
					right = parseUnaryMinus();
					left = new Multiplication(location, left, right);
					break;
				case DIV:
					acceptIt();
					right = parseUnaryMinus();
					left = new Division(location, left, right);
					break;
				default:
					return left;
			}
		}
	}
	

	/**
	 * Parses a Expression, as defined by:
	 * <p>unaryMinus ::= ’-’ ? exponentation
	 * <p>If no negation occures, the result of {@link parseExponentiation} will be returned.
	 * 
	 * 
	 * @return {@link UnaryMinus} or the result of {@link parseExponentiation()}
	 */
	private Expression parseUnaryMinus() {
		SourceLocation location = currentToken.sourceLocation;
		
		if(currentToken.type == SUB) {
			acceptIt();
			return new UnaryMinus(location, parseExponentiation());
		}
		return parseExponentiation();
	}
	

	/**
	 * Parses a Exponentation, as defined by:
	 * <p>exponentation ::= dotProd ( ’^’ dotProd )*
	 * <p>If no power is given, the base will be returned.
	 * 
	 * 
	 * @return {@link parseDotProd} or the result of {@link parseDotProd}
	 */
	private Expression parseExponentiation() {
		SourceLocation location = currentToken.sourceLocation;
		Expression base = parseDotProd();
		
		if(currentToken.type == EXP) {
			acceptIt();
			return new Exponentiation(location, base, parseExponentiation());
		}
		return base;
	}
	
	private Expression parseDotProd() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseMatrixMul();
		while(currentToken.type == DOTPROD) {
			acceptIt();
			x = new DotProduct(location, x, parseMatrixMul());
		}
		return x;
	}
	
	private Expression parseMatrixMul() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseTranspose();
		while(currentToken.type == MATMULT) {
			acceptIt();
			x = new MatrixMultiplication(location, x, parseTranspose());
		}
		return x;
	}
	
	private Expression parseTranspose() {
		SourceLocation location = currentToken.sourceLocation;
		
		if(currentToken.type == TRANSPOSE) {
			acceptIt();
			return new MatrixTranspose(location, parseDim());
		}
		return parseDim();
	}
	
	private Expression parseDim() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseSubRange();
		switch(currentToken.type) {
			case ROWS:
				acceptIt();
				return new MatrixRows(location, x);
			case COLS:
				acceptIt();
				return new MatrixCols(location, x);
			case DIM:
				acceptIt();
				return new VectorDimension(location, x);
			default:
				return x;
		}
	}
	
	private Expression parseSubRange() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseElementSelect();
		
		if(currentToken.type == LBRACE) {
			acceptIt();
			Expression xStartIndex = parseExpr();
			accept(COLON);
			Expression xBaseIndex = parseExpr();
			accept(COLON);
			Expression xEndIndex = parseExpr();
			accept(RBRACE);
			if(currentToken.type != LBRACE)
				return new SubVector(location, x, xBaseIndex, xStartIndex, xEndIndex);
			
			accept(LBRACE);
			Expression yStartIndex = parseExpr();
			accept(COLON);
			Expression yBaseIndex = parseExpr();
			accept(COLON);
			Expression yEndIndex = parseExpr();
			accept(RBRACE);
			return new SubMatrix(location, x, xBaseIndex, xStartIndex, xEndIndex, yBaseIndex, yStartIndex, yEndIndex);
		}
		
		return x;
	}
	
	private Expression parseElementSelect() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseRecordElementSelect();
		
		while(currentToken.type == LBRACKET) {
			acceptIt();
			Expression idx = parseExpr();
			accept(RBRACKET);
			x = new ElementSelect(location, x, idx);
		}
		
		return x;
	}
	
	private Expression parseRecordElementSelect() {
		SourceLocation location = currentToken.sourceLocation;
		
		Expression x = parseAtom();
		
		if(currentToken.type == AT) {
			accept(AT);
			String elementName = accept(ID);
			x = new RecordElementSelect(location, x, elementName);
		}
		
		return x;
	}
	
	private Expression parseAtom() {
		SourceLocation location = currentToken.sourceLocation;
		
		switch(currentToken.type) {
			case INTLIT:
				return new IntValue(location, parseIntLit());
			case FLOATLIT:
				return new FloatValue(location, parseFloatLit());
			case BOOLLIT:
				return new BoolValue(location, parseBoolLit());
			case STRINGLIT:
				return new StringValue(location, accept(STRINGLIT));
			default: /* check other cases below */
		}
		
		if(currentToken.type == ID) {
			String name = accept(ID);
			if(currentToken.type != LPAREN) {
				return new IdentifierReference(location, name);
				
			} else {
				return parseCall(name, location);
			}
		}
		
		if(currentToken.type == LPAREN) {
			acceptIt();
			Expression x = parseExpr();
			accept(RPAREN);
			return x;
		}
		
		if(currentToken.type == AT) {
			acceptIt();
			String name = accept(ID);
			return new RecordInit(location, name, parseInitializerList());
		}
		
		if(currentToken.type == LBRACKET) {
			return new StructureInit(location, parseInitializerList());
		}
		
		throw new SyntaxError(currentToken, INTLIT, FLOATLIT, BOOLLIT, STRINGLIT, ID, LPAREN, LBRACKET, AT);
	}
	
	private List<Expression> parseInitializerList() {
		List<Expression> elements = new ArrayList<>();
		
		accept(LBRACKET);
		elements.add(parseExpr());
		while(currentToken.type == COMMA) {
			accept(COMMA);
			elements.add(parseExpr());
		}
		accept(RBRACKET);
		
		return elements;
	}
	
	private int parseIntLit() {
		return Integer.parseInt(accept(INTLIT));
	}
	
	private float parseFloatLit() {
		return Float.parseFloat(accept(FLOATLIT));
	}
	
	private boolean parseBoolLit() {
		return Boolean.parseBoolean(accept(BOOLLIT));
	}
}
